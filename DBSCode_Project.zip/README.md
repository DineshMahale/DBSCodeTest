
## Folder Structure
`Run tests from command-line through "mvn test" Or from IDE-TestRunner.java`

`Output logs are stored at dbsTestLogs.out`

`Screnshots are saved at src/screenshots`

`HTML reports are saved at /target/HTMLReports/cucumber-html-reports/`

`JSON reports are saved at /target/JSONReports/`

